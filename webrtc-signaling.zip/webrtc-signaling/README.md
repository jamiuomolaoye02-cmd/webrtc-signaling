# WebRTC 1-to-1 Signaling Server

Complete Node.js + Express + Socket.IO signaling server for 1-to-1 WebRTC video calls.

## Files
- `server.js` — signaling backend
- `package.json` — dependencies and start command
- `public/index.html` — browser test page
- `.gitignore` — deployment hygiene

## Deploy on Render
1. Create a GitHub repository and upload all files, preserving `public/index.html`.
2. In Render, create a **Web Service** from the GitHub repository.
3. Runtime: Node.
4. Build Command: `npm install`
5. Start Command: `npm start`
6. Optional Health Check Path: `/health`.
7. Deploy and open the generated `https://...onrender.com` URL.

## Test
Open `/health` and confirm it returns JSON with `"status":"ok"`. Then open the main URL on two devices, use the same room ID, and allow camera/microphone permissions.

## TURN
The server includes Google STUN by default. Some mobile networks require TURN. If you have TURN credentials, set `TURN_URLS`, `TURN_USERNAME`, and `TURN_CREDENTIAL` in the hosting environment. `/ice-config` then includes the TURN server.
