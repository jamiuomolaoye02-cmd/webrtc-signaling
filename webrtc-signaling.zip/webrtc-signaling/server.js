const express = require("express");
const http = require("http");
const path = require("path");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);

const allowedOrigins = (process.env.CORS_ORIGIN || "*").split(",").map(s => s.trim()).filter(Boolean);
const corsOrigin = (origin, callback) => {
  if (!origin || allowedOrigins.includes("*") || allowedOrigins.includes(origin)) return callback(null, true);
  callback(new Error("CORS origin not allowed"));
};

const io = new Server(server, {
  cors: { origin: corsOrigin, methods: ["GET", "POST"] },
  transports: ["websocket", "polling"]
});

app.use(express.static(path.join(__dirname, "public")));

app.get("/health", (req, res) => res.json({ status: "ok", service: "webrtc-signaling", rooms: rooms.size }));

app.get("/ice-config", (req, res) => {
  const iceServers = [{ urls: "stun:stun.l.google.com:19302" }];
  const urls = (process.env.TURN_URLS || "").split(",").map(s => s.trim()).filter(Boolean);
  if (urls.length && process.env.TURN_USERNAME && process.env.TURN_CREDENTIAL) {
    iceServers.push({ urls, username: process.env.TURN_USERNAME, credential: process.env.TURN_CREDENTIAL });
  }
  res.json({ iceServers });
});

app.get("*", (req, res, next) => {
  if (req.path.startsWith("/socket.io") || req.path === "/health" || req.path === "/ice-config") return next();
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

const rooms = new Map();
const socketRoom = new Map();

function validRoomId(roomId) {
  return typeof roomId === "string" && /^[A-Za-z0-9_-]{1,64}$/.test(roomId);
}

function leaveRoom(socket, notify = true) {
  const roomId = socketRoom.get(socket.id);
  if (!roomId) return;
  const room = rooms.get(roomId);
  socketRoom.delete(socket.id);
  socket.leave(roomId);
  if (!room) return;
  room.delete(socket.id);
  if (notify) for (const peerId of room) io.to(peerId).emit("peer-left", { peerId: socket.id });
  if (room.size === 0) rooms.delete(roomId);
}

io.on("connection", socket => {
  socket.on("join-room", ({ roomId } = {}, ack) => {
    ack = typeof ack === "function" ? ack : () => {};
    if (!validRoomId(roomId)) return ack({ ok: false, code: "INVALID_ROOM", error: "Invalid room ID." });
    if (socketRoom.has(socket.id)) leaveRoom(socket, true);
    let room = rooms.get(roomId);
    if (!room) { room = new Set(); rooms.set(roomId, room); }
    if (room.size >= 2) {
      socket.emit("room-full", { roomId });
      return ack({ ok: false, code: "ROOM_FULL", error: "Room is full (maximum 2 people)." });
    }
    const peers = [...room];
    room.add(socket.id);
    socketRoom.set(socket.id, roomId);
    socket.join(roomId);
    ack({ ok: true, roomId, peers });
    for (const peerId of peers) io.to(peerId).emit("peer-joined", { peerId: socket.id });
  });

  socket.on("offer", payload => {
    const roomId = socketRoom.get(socket.id);
    if (roomId && payload && payload.sdp) socket.to(roomId).emit("offer", { sdp: payload.sdp });
  });
  socket.on("answer", payload => {
    const roomId = socketRoom.get(socket.id);
    if (roomId && payload && payload.sdp) socket.to(roomId).emit("answer", { sdp: payload.sdp });
  });
  socket.on("ice-candidate", payload => {
    const roomId = socketRoom.get(socket.id);
    if (roomId && payload && payload.candidate) socket.to(roomId).emit("ice-candidate", { candidate: payload.candidate });
  });
  socket.on("leave-room", () => leaveRoom(socket, true));
  socket.on("disconnect", () => leaveRoom(socket, true));
});

const PORT = Number(process.env.PORT) || 3000;
server.listen(PORT, "0.0.0.0", () => console.log(`WebRTC signaling server listening on 0.0.0.0:${PORT}`));
